import { Resolver, ResolveField, Parent } from '@nestjs/graphql';
import { JobLetterType } from './types/surveyact.types';
import { JobLetter } from '@prisma/client';
import { SurveyActivityService } from './surveyacts.service';

@Resolver(() => JobLetterType)
export class JobLetterResolver {
  constructor(private readonly service: SurveyActivityService) {}

  @ResolveField(() => String, { name: 'eviLetterSignedUrl', nullable: true })
  async eviLetterSignedUrl(@Parent() jl: JobLetter) {
    return this.service.getJobLetterSignedUrl(jl.eviLetterPath ?? null);
  }

  @ResolveField(() => Object, { name: 'user', nullable: true })
  async user(@Parent() jl: JobLetter) {
    try {
      return await this.service.getUser(jl.userId);
    } catch { return null; }
  }

  @ResolveField(() => Object, { name: 'subSurveyActivity', nullable: true })
  async subSurveyActivity(@Parent() jl: JobLetter) {
    return this.service.getSubSurvey(jl.subSurveyActivityId);
  }
}